# -----------------------------------------------------------------------------
# --------------------------  Revision History --------------------------------
#  07-21-2023, Venkat Chidambaram
#  * Initial Version

# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
import datetime
import requests
import json
from PostData import *

from configparser import ConfigParser


# Read config.ini file
config_object = ConfigParser()
config_object.read("config.ini")

headers  = config_object.get("X-API-KEY","x-api-key")



def getPipelineExecutionErrorMsg( api_call):

    executionErrorMessage = ""

    pipelineExecutionDetails = requests.get( api_call, headers=headers)

    jsonPipelineExecDetailsStr = json.dumps( pipelineExecutionDetails.json())

    jsonPipelineExecDetailsObj = json.loads(jsonPipelineExecDetailsStr)

    if "data" in jsonPipelineExecDetailsObj:

        jsonDataStr = jsonPipelineExecDetailsObj['data']

        jsonDataObj = json.loads( json.dumps(jsonDataStr))

        if "pipelineExecutionSummary" in jsonDataObj:

            jsonPipelineExecStr = jsonDataObj['pipelineExecutionSummary']

            jsonPipelineExecObj = json.loads( json.dumps(jsonPipelineExecStr))

            # Error Info exists for failed pipeline
            if "executionErrorInfo" in jsonPipelineExecObj :

                jsonExecutionErrorInfoStr = jsonPipelineExecObj['executionErrorInfo']

                jsonExecutionErrorInfoObj = json.loads( json.dumps( jsonExecutionErrorInfoStr))

                executionErrorMessage = jsonExecutionErrorInfoObj['message']

    return executionErrorMessage


def postDeploymentStages( server, deployment_id, api_call, datalake_processed_releaseids):

    orgIdentifier = ""
    projectIdentifier = ""

    pipelineExecutionDetails = requests.get(api_call,headers=headers)

    jsonPipelineExecDetailsStr = json.dumps( pipelineExecutionDetails.json())

    jsonPipelineExecDetailsObj = json.loads(jsonPipelineExecDetailsStr)

    if "data" in jsonPipelineExecDetailsObj:

        jsonDataStr = jsonPipelineExecDetailsObj['data']

        jsonDataObj = json.loads( json.dumps(jsonDataStr))

        if "pipelineExecutionSummary" in jsonDataObj:

            jsonPipelineExecStr = jsonDataObj['pipelineExecutionSummary']

            jsonPipelineExecObj = json.loads( json.dumps(jsonPipelineExecStr))

            if "orgIdentifier" in jsonPipelineExecObj: orgIdentifier = jsonPipelineExecObj['orgIdentifier']

            if "projectIdentifier" in jsonPipelineExecObj: projectIdentifier = jsonPipelineExecObj['projectIdentifier']

            jsonLayoutNodeMapStr = jsonPipelineExecObj['layoutNodeMap']

            jsonLayoutNodeMapObj = json.loads( json.dumps( jsonLayoutNodeMapStr))

            for i in jsonLayoutNodeMapObj:

                stageUuid = ""
                stageType = ""
                stageName = ""
                stageID = ""
                stageStatus = ""
                stageStatusMessage = ""
                deploymentStages = ""
                stageStartTime = ""
                stageEndTime = ""
                environmentId = ""
                environmentType = ""
                infrastructureName = ""
                deploymentType = ""
                rollbackDuration = ""
                serviceID = ""
                releaseID = ""

                deploymentStages = ""
                releaseToDeployment = ""

                jsonStageStr = jsonLayoutNodeMapObj[i]

                jsonStageObj = json.loads( json.dumps( jsonStageStr))

                if "nodeExecutionId" in jsonStageObj:

                    stageUuid = jsonStageObj['nodeExecutionId']
                    if "nodeType" in jsonStageObj: stageType = jsonStageObj['nodeType']
                    if "name" in jsonStageObj: stageName = jsonStageObj['name']
                    if "nodeIdentifier" in jsonStageObj: stageID = jsonStageObj['nodeIdentifier']
                    if "status" in jsonStageObj: stageStaus = jsonStageObj['status']

                    #StageStartTime
                    if "startTs" in jsonStageObj: stageStartTime  =  str(datetime.datetime.fromtimestamp(jsonStageObj['startTs'] / 1000))
                    #StageEndTime
                    if "endTs" in jsonStageObj: stageEndTime    =  str(datetime.datetime.fromtimestamp(jsonStageObj['endTs'] / 1000))

                    # moduleInfo will exists for type "Deployment"
                    if "failureInfo" in jsonStageObj:

                        jsonFailureInfoStr = jsonStageObj['failureInfo']

                        jsonFailureInfoObj = json.loads( json.dumps( jsonFailureInfoStr))

                        if "message" in jsonFailureInfoObj: stageStatusMessage = jsonFailureInfoObj["message"]

                    # moduleInfo will exists for type "Deployment"
                    if "moduleInfo" in jsonStageObj:

                        jsonModuleInfoStr = jsonStageObj['moduleInfo']

                        jsonModuleInfoObj = json.loads( json.dumps( jsonModuleInfoStr))

                        # Get "rollbackDuraion" under "cd"

                        if "cd" in jsonModuleInfoObj:

                            jsonCDStr = jsonModuleInfoObj['cd']

                            jsonCDObj = json.loads( json.dumps( jsonCDStr))

                            if "rollbackDuration" in jsonCDObj: rollbackDuration = jsonCDObj['rollbackDuration']

                            if "executionGraph" in jsonDataObj:

                                deploymentType, releaseID = getSpecFromExecutionGraph( jsonDataObj['executionGraph'], stageID, orgIdentifier, projectIdentifier)

                            releaseToDeployment = {
                                "ReleaseID": releaseID,
                                "DeploymentStageID": deployment_id + "_" + stageUuid
                            }


                            if "infraExecutionSummary" in jsonCDObj:
                                jsonInfraExecutionSummaryStr = jsonCDObj['infraExecutionSummary']

                                jsonInfraExecutionSummaryObj = json.loads( json.dumps( jsonInfraExecutionSummaryStr))

                                if "identifier" in jsonInfraExecutionSummaryObj: environmentId = jsonInfraExecutionSummaryObj['identifier']
                                if "type" in jsonInfraExecutionSummaryObj: environmentType = jsonInfraExecutionSummaryObj['type']
                                if "infrastructureName" in jsonInfraExecutionSummaryObj: infrastructureName = jsonInfraExecutionSummaryObj['infrastructureName']

                    deploymentStages = {
                        "DeploymentID":deployment_id,
                        "DeploymentStageID": deployment_id + "_" + stageUuid,
                        "StageType": stageType,
                        "StageName": stageName,
                        "StageStartTime": stageStartTime,
                        "StageEndTime": stageEndTime,
                        "EnvironmentID": environmentId,
                        "EnvironmentType": environmentType,
                        "EnvironmentTags":"",
                        "InfrastructureName": infrastructureName,
                        "DeploymentType": deploymentType,
                        "StageStatus": stageStaus,
                        "StageStatusMessage": stageStatusMessage,
                        "RollbackDuration": rollbackDuration
                    }

                    postData( server, "deploymentStages", deploymentStages, deployment_id + "_" + stageUuid)
                    if releaseToDeployment != "":
                        postData( server, "releaseToDeployment", releaseToDeployment, deployment_id + "_" + stageUuid)
                        datalake_processed_releaseids.write( deployment_id + "_" + stageUuid + "  "+ releaseID + "\n")

def getSpecFromExecutionGraph( jsonExecutionGraph, stageID, orgIdentifier, projectIdentifier):

    deploymentType = ""
    releaseID = ""
    artifactURL = ""
    artifactPath = ""
    repositoryName = ""

    baseFqn = "pipeline.stages.Download_Artifact.spec"

    jsonExecutionGraph = json.loads( json.dumps(jsonExecutionGraph))

    if "nodeMap" in jsonExecutionGraph:

        jsonNodeMapStr = jsonExecutionGraph['nodeMap']

        jsonNodeMapObj = json.loads( json.dumps( jsonNodeMapStr))

        for nodeMapIndex in jsonNodeMapObj:

            jsonExecutionNodeStr = jsonNodeMapObj[nodeMapIndex]
            jsonExecutionNodeObj = json.loads( json.dumps( jsonExecutionNodeStr))

            if ("name" in jsonExecutionNodeObj) and ("baseFqn" in jsonExecutionNodeObj):

                #if jsonExecutionNodeObj['name'] == 'Service' and jsonExecutionNodeObj['baseFqn'] == 'pipeline.stages.'+ stageID + '.spec':
                if jsonExecutionNodeObj['name'] == 'Service' :
                        if "outcomes" in jsonExecutionNodeObj:

                                jsonOutcomesStr = jsonExecutionNodeObj['outcomes']

                                jsonOutcomesObj = json.loads( json.dumps( jsonOutcomesStr))

                                if "service" in jsonOutcomesObj:

                                    jsonServiceStr = jsonOutcomesObj['service']

                                    jsonServiceObj = json.loads( json.dumps( jsonServiceStr))

                                    if "type" in jsonServiceObj: deploymentType = jsonServiceObj['type']

                                # Artifact type
                                if "artifacts" in jsonOutcomesObj:

                                    jsonArtifactsStr = jsonOutcomesObj['artifacts']

                                    jsonArtifactObj = json.loads( json.dumps( jsonArtifactsStr))

                                    if "primary" in jsonArtifactObj:

                                        jsonPrimaryArtifactStr = jsonArtifactObj['primary']

                                        jsonPrimaryArtifactObj = json.loads( json.dumps( jsonPrimaryArtifactStr))

                                        if "connectorRef" in  jsonPrimaryArtifactObj:

                                            connectorRef = jsonPrimaryArtifactObj['connectorRef']

                                            if connectorRef != "": artifactURL = getArtifactURL( connectorRef, orgIdentifier, projectIdentifier)

                                        if "repositoryName" in jsonPrimaryArtifactObj:

                                            repositoryName = jsonPrimaryArtifactObj['repositoryName']

                                            if repositoryName != "": repositoryName = repositoryName + "/"

                                        if "artifactPath" in jsonPrimaryArtifactObj: artifactPath = jsonPrimaryArtifactObj['artifactPath']

                                        releaseID = artifactURL + repositoryName + artifactPath

                                # Helm type
                                if "manifests" in jsonOutcomesObj:

                                    jsonManifests = jsonOutcomesObj['manifests']

                                    jsonManifestsObj = json.loads( json.dumps( jsonManifests))

                                    if "Chart" in jsonManifestsObj:

                                        jsonChart = jsonManifestsObj['Chart']

                                        jsonChartObj = json.loads( json.dumps( jsonChart))

                                        if "store" in jsonChartObj:

                                            jsonStore = jsonChartObj['store']

                                            jsonStoreObj = json.loads( json.dumps( jsonStore))

                                            if "connectorRef" in jsonStoreObj:

                                                connectorRef = jsonStoreObj['connectorRef']

                                                if connectorRef != "": artifactURL = getArtifactURL( connectorRef, orgIdentifier, projectIdentifier)

                                        if "chartName" in jsonChartObj:

                                            repositoryName = jsonChartObj['chartName']
                                            if repositoryName != "": repositoryName = repositoryName + "/"

                                        if "chartVersion" in jsonChartObj: artifactPath = jsonChartObj['chartVersion']

                                        releaseID = artifactURL + repositoryName + artifactPath

    return deploymentType, releaseID


def getArtifactURL( connectorRef, orgIdentifier, projectIdentifier):

    connector = connectorRef
    url = ""

    if len( connectorRef.split(".", 1)) > 1: connector = connectorRef.split(".", 1)[1]

    api_call_connector = 'https://app.harness.io/ng/api/connectors/' + connector + '?accountIdentifier=XzgUIuZXRMWymCzLKYZpCg'

    if connectorRef.startswith("org."):
        api_call_connector = api_call_connector + '&orgIdentifier=' + orgIdentifier
    else:
        api_call_connector = api_call_connector + '&orgIdentifier=' + orgIdentifier + '&projectIdentifier='+ projectIdentifier

    connectorDetails = requests.get( api_call_connector, headers=headers)

    jsonConnectorDetailsStr = json.dumps( connectorDetails.json())

    jsonConnectorDetailsObj = json.loads( jsonConnectorDetailsStr)

    if "data" in jsonConnectorDetailsObj:

        jsonConnectorDataStr = json.dumps( jsonConnectorDetailsObj['data'])

        jsonConnectorDataObj = json.loads( jsonConnectorDataStr)

        if "connector" in jsonConnectorDataObj:

            jsonConnectorStr = json.dumps( jsonConnectorDataObj['connector'])

            jsonConnectorObj = json.loads( jsonConnectorStr)

            if "spec" in jsonConnectorObj:

                jsonSpecStr = json.dumps( jsonConnectorObj['spec'])

                jsonSpecObj = json.loads( jsonSpecStr)

                if "artifactoryServerUrl" in jsonSpecObj: url = jsonSpecObj['artifactoryServerUrl']

                if "helmRepoUrl" in jsonSpecObj: url = jsonSpecObj['helmRepoUrl']

    return url
