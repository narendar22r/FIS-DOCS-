import requests
import json
import random

from configparser import ConfigParser


# Read config.ini file
config_object = ConfigParser()
config_object.read("config.ini")

requests.packages.urllib3.disable_warnings()

num = random.randrange(333, 50000, 5)

retryLimit = config_object.getint("RETRY_LIMIT","retryLimit")


headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        "source-id": "Jenkins",
        "uuid": f"45411c3c25c-c6b8-42d1-8cbc-{num}"
        }

def postData(server, module, payLoad, id):

        url = config_object[server][module]
        if url is None:
            raise ValueError("URL not found in the configuration for server: {} and module: {}".format(server, module))
            #print("please provide the correct server type and module")
        #res = requests.post(url, verify=False, data=json.dumps(payLoad), headers=headers, cert='./ciserver.pem')
        #res.close()
        #print(url)
        postAndCheckStatus( url, payLoad, id)
   

# Example usage:
#postData("PROD", "deploymentStages", "gjjgh", 12)


def postAndCheckStatus(url, payLoad, id):
    isPostSuccess = False
    retry = 0

    while retry < retryLimit:
        response = requests.post(url, verify=False, data=json.dumps(payLoad), headers=headers, cert='./ciserver.pem')
        # print(response.content)
        # print("")
        try:
            resStatusJson = response.json()

            if "status" in resStatusJson:
                if resStatusJson['status'] == 'success':
                    isPostSuccess = True
                    break
                else:
                    retry = retry + 1
        except Exception as e:
            retry = retry + 1

    response.close()

    if isPostSuccess is False:
        raise Exception("Post Failed To URL: " + url + " , ID: " + id + ' response: ' + response.text)


