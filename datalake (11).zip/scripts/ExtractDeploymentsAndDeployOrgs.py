# -----------------------------------------------------------------------------
# --------------------------  Revision History --------------------------------
#  07-21-2023, Venkat Chidambaram
#  * Initial Version

# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
import sys
import csv
import requests
import json
import traceback
from PostData import *
from ExtractDeploymentStages import *
from datetime import datetime

if(__name__ == '__main__'):

    # pipeline execution id is passed as a first parameter
    pipeline_execution_id = sys.argv[1]
    # server type to post data - DEV, UAT, PROD
    server = sys.argv[2]

     # Log file for tracking processed deployments ID posted for each build.
    datalake_processed_deployments = open( "../logs/datalake_processed_deployments-"+ pipeline_execution_id +".log", "w")

     # Log file for tracking processed deployments ID posted for each build.
    datalake_processed_releaseids = open( "../logs/datalake_processed_releaseids-"+ pipeline_execution_id +".log", "w")

    # Log file for tracking errors for each build.
    datalake_error = open( "../logs/datalake_error-"+ pipeline_execution_id +".log", "w")

    try:

        # Open DeployData.csv which contains the dashboard data downloaded from Harness to be processed
        with open('/home/docker/DataLake/Deployments.csv') as deployData:

            # Create reader object by passing the file
            # object to reader method
            reader_obj = csv.reader(deployData)

            # Open Deployments_Repost to write unprocessed records
            with open( "/home/docker/DataLake/Deployments_Repost.csv", "w") as deployData_repost:

                writer_obj = csv.writer( deployData_repost, delimiter=",")

                # Iterate over each row in the csv
                # file using reader object
                for row in reader_obj:
                    try:
                        # quit if no record found
                        if row == []:
                                break

                        org_id          = row[0]        # Organization ID
                        project_id      = row[1]        # Project ID
                        deployedBy      = row[2]        # Deployed By
                        deployStartDate = row[3]        # Deploy start Date
                        deployEndDate   = row[4]        # Deploy End Date
                        deployStatus    = row[5]        # Deploy Status
                        deploymentType  = row[6]        # Deploy Type
                        pipeline_execution_url=row[7]   # Pipeline execution URL of a deployment

                        #Get the pipeline execution id from the execution URL - Deploy ID
                        pipeline_execution_id=pipeline_execution_url.split('/',15)[-1].replace('/pipeline','')

                        # DeploymentOrg
                        deploymentOrgID         =  'app.harness.io_' + org_id
                        # DeploymentOrg+Project
                        deploymntProjectID      = deploymentOrgID + '_' + project_id
                        # DeploymentOrg+Project+PipelienExctuion
                        deploymentID            = deploymntProjectID + '_' + pipeline_execution_id

                        # API call for Pipeline Execution Details
                        api_call = 'https://app.harness.io/pipeline/api/pipelines/execution/v2/' + pipeline_execution_id + '?accountIdentifier=XzgUIuZXRMWymCzLKYZpCg&orgIdentifier=' + org_id + '&projectIdentifier=' + project_id + '&renderFullBottomGraph=true'

                        # Deployment error message exists in pipeline execution detail
                        executionErrorMessage = getPipelineExecutionErrorMsg(  api_call)

                        # Deployment Data
                        deployments = {
                            "DeploymentID":deploymentID,
                            "DeploymentOrgID":deploymentOrgID,
                            "DeploymentProjectID":deploymntProjectID,
                            "DeploymentTriggerType": deploymentType,
                            "DeploymentStartDate":deployStartDate,
                            "DeploymentEndDate": deployEndDate,
                            "DeployedBy":deployedBy,
                            "DeploymentStatus":deployStatus,
                            #"DeploymentStatusMessage": executionErrorMessage
                            "DeploymentStatus":''
                        }

                        # Org Data
                        deploymentsOrgs = {
                            "DeploymentOrgID":deploymentOrgID,
                            "DeploymentPlatform":"app.harness.io",
                            "OrgName":org_id,
                            "OrgURL":"https://app.harness.io/ng/account/XzgUIuZXRMWymCzLKYZpCg/settings/organizations/"+ org_id + "/details"
                        }

                        # Post Deployment Data
                        postData( server, "deployments", deployments, deploymentID)

                        # Post Org Data
                        postData( server, "deploymentOrgs", deploymentsOrgs, deploymentID)

                        # Extract and Post Deployment Stages
                        postDeploymentStages( server, deploymentID, api_call, datalake_processed_releaseids)

                    except Exception as e:
                        #print(traceback.format_exc())
                        datalake_error.write( deploymentID + "           " + str( e) + "\n")
                        writer_obj.writerow( row)
                    else:
                        datalake_processed_deployments.write( deploymentID + "\n")

    except Exception as e:
        datalake_error.write( deploymentID + "           " + str( e) + "\n")

    finally:
        datalake_processed_releaseids.close()
        datalake_error.close()
        datalake_processed_deployments.close()
        deployData_repost.close()
        deployData.close()
